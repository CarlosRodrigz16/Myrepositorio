package com.gestionacademica.service;

import com.gestionacademica.model.Estudiante;
import com.gestionacademica.repository.EstudianteRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EstudianteService {

    private final EstudianteRepository estudianteRepository;

    public EstudianteService(EstudianteRepository estudianteRepository) {
        this.estudianteRepository = estudianteRepository;
    }

    public List<Estudiante> getAllStudents() {
        return estudianteRepository.findAll();
    }

    public Optional<Estudiante> getStudentById(Long id) {
        return estudianteRepository.findById(id);
    }

    public Estudiante saveStudent(Estudiante estudiante) {
        return estudianteRepository.save(estudiante);
    }

    public void deleteStudent(Long id) {
        estudianteRepository.deleteById(id);
    }
}


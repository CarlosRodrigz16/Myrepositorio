package com.gestionacademica.service;

import com.gestionacademica.model.Calificacion;
import com.gestionacademica.repository.CalificacionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalificacionService {

    private final CalificacionRepository calificacionRepository;

    public CalificacionService(CalificacionRepository calificacionRepository) {
        this.calificacionRepository = calificacionRepository;
    }

    public Calificacion crearCalificacion(Calificacion calificacion) {
        return calificacionRepository.save(calificacion);
    }

    public List<Calificacion> getCalificacionesPorEstudiante(Long estudianteId) {
        return calificacionRepository.findByEstudianteId(estudianteId);
    }

    public List<Calificacion> getCalificacionesPorCurso(Long cursoId) {
        return calificacionRepository.findByCursoId(cursoId);
    }

    public Double obtenerPromedioPorEstudiante(Long estudianteId) {
        return calificacionRepository.findPromedioByEstudianteId(estudianteId);
    }
}



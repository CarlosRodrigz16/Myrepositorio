package com.gestionacademica.service;

import com.gestionacademica.model.Docente;
import com.gestionacademica.repository.DocenteRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DocenteService {

    private final DocenteRepository docenteRepository;

    public DocenteService(DocenteRepository docenteRepository) {
        this.docenteRepository = docenteRepository;
    }

    public Docente crearDocente(Docente docente) {
        return docenteRepository.save(docente);
    }

    public List<Docente> listarDocentes() {
        return docenteRepository.findAll();
    }

    public Optional<Docente> obtenerDocentePorId(Long id) {
        return docenteRepository.findById(id);
    }

    public Docente actualizarDocente(Long id, Docente docenteActualizado) {
        return docenteRepository.findById(id).map(docente -> {
            docente.setNombre(docenteActualizado.getNombre());
            docente.setApellido(docenteActualizado.getApellido());
            docente.setCorreo(docenteActualizado.getCorreo());
            docente.setTelefono(docenteActualizado.getTelefono());
            docente.setDireccion(docenteActualizado.getDireccion());
            docente.setEspecialidad(docenteActualizado.getEspecialidad());
            docente.setFechaContratacion(docenteActualizado.getFechaContratacion());
            return docenteRepository.save(docente);
        }).orElseThrow(() -> new RuntimeException("Docente no encontrado"));
    }

    public void eliminarDocente(Long id) {
        docenteRepository.deleteById(id);
    }
}


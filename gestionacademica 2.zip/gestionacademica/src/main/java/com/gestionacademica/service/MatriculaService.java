package com.gestionacademica.service;

import org.springframework.stereotype.Service;

import com.gestionacademica.model.Estudiante;
import com.gestionacademica.model.Matricula;
import com.gestionacademica.model.Curso;
import com.gestionacademica.repository.CursoRepository;
import com.gestionacademica.repository.EstudianteRepository;
import com.gestionacademica.repository.MatriculaRepository;
import com.gestionacademica.dto.MatriculaRequestDTO;

@Service
public class MatriculaService {

    private final MatriculaRepository matriculaRepository;
    private final EstudianteRepository estudianteRepository;
    private final CursoRepository cursoRepository;

    public MatriculaService(MatriculaRepository matriculaRepository, 
                            EstudianteRepository estudianteRepository, 
                            CursoRepository cursoRepository) {
        this.matriculaRepository = matriculaRepository;
        this.estudianteRepository = estudianteRepository;
        this.cursoRepository = cursoRepository;
    }

    public Matricula crearMatricula(MatriculaRequestDTO matriculaRequestDTO) {
        Estudiante estudiante = estudianteRepository.findById(matriculaRequestDTO.getEstudianteId())
                .orElseThrow(() -> new RuntimeException("Estudiante no encontrado"));

        Curso curso = cursoRepository.findById(matriculaRequestDTO.getCursoId())
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        Matricula matricula = new Matricula();
        matricula.setEstudiante(estudiante);
        matricula.setCurso(curso);
        matricula.setFechaMatricula(matriculaRequestDTO.getFechaMatricula());
        matricula.setActivo(matriculaRequestDTO.isActivo());

        return matriculaRepository.save(matricula);
    }
}




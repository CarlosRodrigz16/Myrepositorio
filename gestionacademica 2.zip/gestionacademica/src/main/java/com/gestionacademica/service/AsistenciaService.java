package com.gestionacademica.service;

import org.springframework.stereotype.Service;

import com.gestionacademica.dto.AsistenciaRequestDTO;
import com.gestionacademica.model.Asistencia;
import com.gestionacademica.model.Estudiante;
import com.gestionacademica.model.Curso;
import com.gestionacademica.repository.AsistenciaRepository;
import com.gestionacademica.repository.CursoRepository;
import com.gestionacademica.repository.EstudianteRepository;
import java.time.LocalDateTime;


@Service
public class AsistenciaService {

    private final AsistenciaRepository asistenciaRepository;
    private final EstudianteRepository estudianteRepository;
    private final CursoRepository cursoRepository;

    public AsistenciaService(AsistenciaRepository asistenciaRepository,
                             EstudianteRepository estudianteRepository,
                             CursoRepository cursoRepository) {
        this.asistenciaRepository = asistenciaRepository;
        this.estudianteRepository = estudianteRepository;
        this.cursoRepository = cursoRepository;
    }

    public Asistencia registrarAsistencia(AsistenciaRequestDTO asistenciaRequestDTO) {
    Estudiante estudiante = estudianteRepository.findById(asistenciaRequestDTO.getEstudianteId())
            .orElseThrow(() -> new RuntimeException("Estudiante no encontrado"));

    Curso curso = cursoRepository.findById(asistenciaRequestDTO.getCursoId())
            .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

    LocalDateTime fechaClase = asistenciaRequestDTO.getFecha();

    Asistencia asistencia = new Asistencia(estudiante, curso, fechaClase, asistenciaRequestDTO.isPresente());

    return asistenciaRepository.save(asistencia);
}

}





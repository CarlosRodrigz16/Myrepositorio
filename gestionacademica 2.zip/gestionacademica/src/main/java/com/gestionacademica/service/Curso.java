package com.gestionacademica.service;

public class Curso {

}

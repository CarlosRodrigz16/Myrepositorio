package com.gestionacademica.repository;

import com.gestionacademica.model.Calificacion;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CalificacionRepository extends JpaRepository<Calificacion, Long> {
    List<Calificacion> findByEstudianteId(Long estudianteId);
    List<Calificacion> findByCursoId(Long cursoId);
    List<Calificacion> findByEstudianteIdAndCursoId(Long estudianteId, Long cursoId);
    List<Calificacion> findByCalificacionGreaterThanEqual(Double calificacion);
    
    @Query("SELECT AVG(c.calificacion) FROM Calificacion c WHERE c.estudiante.id = :estudianteId")
    Double findPromedioByEstudianteId(@Param("estudianteId") Long estudianteId);
}


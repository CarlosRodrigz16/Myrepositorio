package com.gestionacademica.repository;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.gestionacademica.model.Asistencia;
import com.gestionacademica.model.Curso;
import com.gestionacademica.model.Estudiante;

@Repository
public interface AsistenciaRepository extends JpaRepository<Asistencia, Long> {

    List<Asistencia> findByEstudiante_Id(Long estudianteId); 
    List<Asistencia> findByCurso_Id(Long cursoId);

    List<Asistencia> findByEstudianteAndFechaClaseBetween(Estudiante estudiante, LocalDateTime fechaInicio, LocalDateTime fechaFin);
    List<Asistencia> findByEstudianteAndFechaClase(Estudiante estudiante, LocalDateTime fechaClase);
    List<Asistencia> findByCursoAndFechaClaseBetween(Curso curso, LocalDateTime fechaInicio, LocalDateTime fechaFin);
    List<Asistencia> findByPresente(Boolean presente);
}


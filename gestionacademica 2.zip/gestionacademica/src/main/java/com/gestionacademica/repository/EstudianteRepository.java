package com.gestionacademica.repository;

import com.gestionacademica.model.Estudiante;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EstudianteRepository extends JpaRepository<Estudiante, Long>  {
    List<Estudiante> findByNombre(String nombre);
    List<Estudiante> findByApellido(String apellido);
    List<Estudiante> findByNombreContainingOrApellidoContaining(String nombre, String apellido);
}

package com.gestionacademica.repository;

import com.gestionacademica.model.Matricula;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface MatriculaRepository extends JpaRepository<Matricula, Long> {

    List<Matricula> findByEstudiante_Id(Long estudianteId);

    List<Matricula> findByCurso_Id(Long cursoId);

    Optional<Matricula> findByEstudiante_IdAndCurso_Id(Long estudianteId, Long cursoId);

    List<Matricula> findByActivoTrue();

    @Query("SELECT COUNT(m) FROM Matricula m WHERE m.estudiante.id = :estudianteId AND m.activo = true")
    Long countActivasPorEstudiante(@Param("estudianteId") Long estudianteId);

    List<Matricula> findByFechaMatriculaBetween(LocalDate fechaInicio, LocalDate fechaFin);

    List<Matricula> findByEstudiante_IdAndActivoTrue(Long estudianteId);
}  



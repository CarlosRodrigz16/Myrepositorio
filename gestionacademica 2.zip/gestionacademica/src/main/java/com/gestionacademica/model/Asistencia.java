package com.gestionacademica.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "asistencias")
public class Asistencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "estudiante_id", nullable = false)
    private Estudiante estudiante;

    @ManyToOne(optional = false)
    @JoinColumn(name = "curso_id", nullable = false)
    private Curso curso;

    @Column(name = "fecha_clase", nullable = false)
    private LocalDateTime fechaClase;

    @Column(nullable = false)
    private Boolean presente;


    public Asistencia() {
    }

    public Asistencia(Estudiante estudiante, Curso curso, LocalDateTime fechaClase, Boolean presente) {
        this.estudiante = estudiante;
        this.curso = curso;
        this.fechaClase = fechaClase;
        this.presente = presente != null ? presente : false;
    }

    public Long getId() {
        return id;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public LocalDateTime getFechaClase() {
        return fechaClase;
    }

    public void setFechaClase(LocalDateTime fechaClase) {
        this.fechaClase = fechaClase;
    }

    public Boolean getPresente() {
        return presente;
    }

    public void setPresente(Boolean presente) {
        this.presente = presente != null ? presente : false;
    }
}




package com.gestionacademica.dto;

import java.util.List;

public class AsignarCursosDTO {
    private Long docenteId;
    private List<Long> cursoIds;

    public Long getDocenteId() { return docenteId; }
    public void setDocenteId(Long docenteId) { this.docenteId = docenteId; }

    public List<Long> getCursoIds() { return cursoIds; }
    public void setCursoIds(List<Long> cursoIds) { this.cursoIds = cursoIds; }
}

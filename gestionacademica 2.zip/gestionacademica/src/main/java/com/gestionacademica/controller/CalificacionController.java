package com.gestionacademica.controller;

import com.gestionacademica.dto.CalificacionRequestDTO;
import com.gestionacademica.exception.ResourceNotFoundException;
import com.gestionacademica.model.Calificacion;
import com.gestionacademica.model.Curso;
import com.gestionacademica.model.Estudiante;
import com.gestionacademica.repository.CursoRepository;
import com.gestionacademica.repository.EstudianteRepository;
import com.gestionacademica.service.CalificacionService;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/calificaciones")
public class CalificacionController {

    private final CalificacionService calificacionService;
    private final EstudianteRepository estudianteRepository; 
    private final CursoRepository cursoRepository; 

    public CalificacionController(CalificacionService calificacionService, EstudianteRepository estudianteRepository, 
                                  CursoRepository cursoRepository) {
        this.calificacionService = calificacionService;
        this.estudianteRepository = estudianteRepository;
        this.cursoRepository = cursoRepository;
    }

    @PostMapping
    public ResponseEntity<Calificacion> crearCalificacion(@RequestBody CalificacionRequestDTO calificacionRequestDTO) {
        Estudiante estudiante = estudianteRepository.findById(calificacionRequestDTO.getEstudianteId())
            .orElseThrow(() -> new ResourceNotFoundException("Estudiante no encontrado"));
        Curso curso = cursoRepository.findById(calificacionRequestDTO.getCursoId())
            .orElseThrow(() -> new ResourceNotFoundException("Curso no encontrado"));

        Calificacion calificacion = new Calificacion();
        calificacion.setCalificacion(calificacionRequestDTO.getCalificacion());
        calificacion.setEstudiante(estudiante);
        calificacion.setCurso(curso);

        Calificacion nuevaCalificacion = calificacionService.crearCalificacion(calificacion);

        return ResponseEntity.ok(nuevaCalificacion);
    }

    @GetMapping("/estudiante/{estudianteId}")
    public ResponseEntity<List<Calificacion>> obtenerCalificacionesPorEstudiante(@PathVariable Long estudianteId) {
        List<Calificacion> calificaciones = calificacionService.getCalificacionesPorEstudiante(estudianteId);
        return ResponseEntity.ok(calificaciones);
    }

    @GetMapping("/curso/{cursoId}")
    public ResponseEntity<List<Calificacion>> obtenerCalificacionesPorCurso(@PathVariable Long cursoId) {
        List<Calificacion> calificaciones = calificacionService.getCalificacionesPorCurso(cursoId);
        return ResponseEntity.ok(calificaciones);
    }

    @GetMapping("/promedio/estudiante/{estudianteId}")
    public ResponseEntity<Double> obtenerPromedioPorEstudiante(@PathVariable Long estudianteId) {
        Double promedio = calificacionService.obtenerPromedioPorEstudiante(estudianteId);
        return ResponseEntity.ok(promedio);
    }
}








package com.gestionacademica.controller;

import com.gestionacademica.exception.ResourceNotFoundException;
import com.gestionacademica.model.Estudiante;
import com.gestionacademica.service.EstudianteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/students")
public class EstudianteController {

    private final EstudianteService estudianteService;

    public EstudianteController(EstudianteService estudianteService) {
        this.estudianteService = estudianteService;
    }

    @GetMapping
    public List<Estudiante> getAllStudents() {
        return estudianteService.getAllStudents();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Estudiante> getStudentById(@PathVariable Long id) {
        Optional<Estudiante> estudiante = estudianteService.getStudentById(id);
        return estudiante.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Estudiante> saveStudent(@RequestBody Estudiante estudiante) {
        Estudiante savedEstudiante = estudianteService.saveStudent(estudiante);
        return ResponseEntity.status(201).body(savedEstudiante);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        estudianteService.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
public ResponseEntity<Estudiante> updateStudent(@PathVariable Long id, @RequestBody Estudiante updatedEstudiante) {
    return estudianteService.getStudentById(id).map(estudiante -> {
      
        estudiante.setNombre(updatedEstudiante.getNombre());
        estudiante.setApellido(updatedEstudiante.getApellido());
        estudiante.setEmail(updatedEstudiante.getEmail());
        estudiante.setTelefono(updatedEstudiante.getTelefono());
        estudiante.setDireccion(updatedEstudiante.getDireccion());
        estudiante.setCarrera(updatedEstudiante.getCarrera());  

        Estudiante savedEstudiante = estudianteService.saveStudent(estudiante);
        return ResponseEntity.ok(savedEstudiante);
    }).orElseThrow(() -> new ResourceNotFoundException("Estudiante no encontrado con id " + id));
}

}



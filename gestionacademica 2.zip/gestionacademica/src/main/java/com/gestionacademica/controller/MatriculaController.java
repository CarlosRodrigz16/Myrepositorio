package com.gestionacademica.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gestionacademica.dto.MatriculaRequestDTO;
import com.gestionacademica.model.Matricula;
import com.gestionacademica.service.MatriculaService;

@RestController
@RequestMapping("/matriculas")
public class MatriculaController {

    private final MatriculaService matriculaService;

    public MatriculaController(MatriculaService matriculaService) {
        this.matriculaService = matriculaService;
    }

    @PostMapping
    public ResponseEntity<Matricula> crearMatricula(@RequestBody MatriculaRequestDTO matriculaRequestDTO) {
        try {
            Matricula matricula = matriculaService.crearMatricula(matriculaRequestDTO);
            return new ResponseEntity<>(matricula, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST); 
        }
    }
}





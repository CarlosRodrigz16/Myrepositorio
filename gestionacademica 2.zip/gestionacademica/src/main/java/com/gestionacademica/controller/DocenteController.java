package com.gestionacademica.controller;

import com.gestionacademica.model.Docente;
import com.gestionacademica.service.DocenteService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/docentes")
public class DocenteController {

    private final DocenteService docenteService;

    public DocenteController(DocenteService docenteService) {
        this.docenteService = docenteService;
    }

    @PostMapping
    public ResponseEntity<Docente> crearDocente(@RequestBody Docente docente) {
        return ResponseEntity.ok(docenteService.crearDocente(docente));
    }

    @GetMapping
    public ResponseEntity<List<Docente>> listarDocentes() {
        return ResponseEntity.ok(docenteService.listarDocentes());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Docente> obtenerDocente(@PathVariable Long id) {
        return docenteService.obtenerDocentePorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Docente> actualizarDocente(@PathVariable Long id, @RequestBody Docente docente) {
        return ResponseEntity.ok(docenteService.actualizarDocente(id, docente));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDocente(@PathVariable Long id) {
        docenteService.eliminarDocente(id);
        return ResponseEntity.noContent().build();
    }
}

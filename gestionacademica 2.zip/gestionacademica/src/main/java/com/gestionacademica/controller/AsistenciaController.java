package com.gestionacademica.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gestionacademica.dto.AsistenciaRequestDTO;
import com.gestionacademica.model.Asistencia;
import com.gestionacademica.service.AsistenciaService;

@RestController
@RequestMapping("/asistencias")
public class AsistenciaController {

    private final AsistenciaService asistenciaService;

    public AsistenciaController(AsistenciaService asistenciaService) {
        this.asistenciaService = asistenciaService;
    }

    @PostMapping
    public ResponseEntity<Asistencia> registrarAsistencia(@RequestBody AsistenciaRequestDTO asistenciaRequestDTO) {
        try {
            Asistencia asistencia = asistenciaService.registrarAsistencia(asistenciaRequestDTO);
            return new ResponseEntity<>(asistencia, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }
}




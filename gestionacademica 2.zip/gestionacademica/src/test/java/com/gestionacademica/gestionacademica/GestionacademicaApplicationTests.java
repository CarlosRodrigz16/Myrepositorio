package com.gestionacademica.gestionacademica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionacademicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
